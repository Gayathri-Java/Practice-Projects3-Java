package Project2;

import java.util.Arrays;
import java.util.Collections;

class element {
		public static int fourthSmallest(Integer[] arr, int K)
	{
		// Sort the given array
		Arrays.sort(arr);
		return arr[K - 1];
	}

	
	public static void main(String[] args)
	{
		Integer arr[] = new Integer[] { 12, 3, 5, 7, 19 };
		int K = 4;

		System.out.print("K'th smallest element is "
						+ fourthSmallest(arr, K));
	}
}


