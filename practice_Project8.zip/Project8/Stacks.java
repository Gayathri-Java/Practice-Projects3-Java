package Project8;

public class Stacks {
    private int maxSize;
    private int top;
    private int[] stackArray;

    public Stacks(int size) {
        maxSize = size;
        stackArray = new int[maxSize];
        top = -1;
    }

    public void push(int value) {
        if (top < maxSize - 1) {
            stackArray[++top] = value;
            System.out.println("Pushed " + value + " to the stack.");
        } else {
            System.out.println("Stack is full. Cannot push " + value + " onto the stack.");
        }
    }

    public int pop() {
        if (top >= 0) {
            int poppedValue = stackArray[top--];
            System.out.println("Popped " + poppedValue + " from the stack.");
            return poppedValue;
        } else {
            System.out.println("Stack is empty. Cannot pop from an empty stack.");
            return -1;
        }
    }

    public static void main(String[] args) {
        Stacks stack = new Stacks(5);

        stack.push(10);
        stack.push(20);

        int poppedValue = stack.pop();
        poppedValue = stack.pop();
        poppedValue = stack.pop();
        

    }
}